"""נרמול עברית וחיפוש מילים – תאום של worker/src/hebrew.js ו-excerpt() ב-worker/src/index.js."""
import re

FIN = str.maketrans("ךםןףץ", "כמנפצ")
STOP = set(("של את על עמ אמ או גמ כי לא מה מי זה זו זאת הוא היא המ הנ יש אינ כל אל כמו איכ למה מתי היכנ איפה האמ אשר "
            "אני אתה הרב אומר כותב בעניינ בנושא לגבי אודות").split())
PRE = "והבלמשכ"
ADD = ["ה", "ו", "ב", "ל", "מ", "ש", "כ", "וה", "שה", "וב", "ול", "ומ", "וש", "וכ", "כש", "מה", "לכ", "בכ"]


def norm(s):
    s = re.sub(r"[\u0591-\u05C7]", "", s or "")
    s = re.sub(r"[״\"׳'`’]", "", s).lower().translate(FIN)
    return re.sub(r"[^א-תa-z0-9]+", " ", s).strip()


def variants(w):
    out = []

    def star(f):
        x = f'"{f}" *' if len(f) >= 3 else f'"{f}"'
        if x not in out:
            out.append(x)
    star(w)
    if w[0] in PRE and len(w) >= 4:
        star(w[1:])
    if w[0] in PRE and len(w) >= 5 and w[1] in PRE:
        star(w[2:])
    for p in ADD:
        star(p + w)
    return out


def fts_query(text, any_=False):
    words = list(dict.fromkeys(w for w in norm(text).split() if len(w) >= 2 and w not in STOP))[:12]
    if not words:
        return None, []
    return (" OR " if any_ else " AND ").join("(" + " OR ".join(variants(w)) + ")" for w in words), words


_FINRE = {"כ": "[כך]", "מ": "[מם]", "נ": "[נן]", "פ": "[פף]", "צ": "[צץ]"}


def excerpt(text, words, size):
    flat = re.sub(r"\\?[*#|]+|\[\^?\d+\]\([^)]*\)|[\u200e\u200f]", " ", text)
    flat = re.sub(r"\s+", " ", flat).strip()
    at = -1
    for w in words:
        m = re.search("[\u0591-\u05C7\"״'׳]*".join(_FINRE.get(c, re.escape(c)) for c in w), flat)
        if m:
            at = m.start()
            break
    start = max(0, at - size // 3)
    return ("…" if start else "") + flat[start:start + size] + ("…" if start + size < len(flat) else "")


# ---------- כותרות בעברית (מ-24.11.2026): "Chapter 2 › Halakhah 3" -> "פרק ב › הלכה ג". בספריא שמות הרמות באנגלית
LEVELS = {"Chapter": "פרק", "Perek": "פרק", "Siman": "סימן", "Daf": "דף", "Halakhah": "הלכה", "Halacha": "הלכה", "Verse": "פסוק",
          "Mishnah": "משנה", "Mishna": "משנה", "Section": "סעיף", "Seif": "סעיף", "Se'if": "סעיף", "Seif Katan": "ס״ק",
          "Paragraph": "פסקה", "Segment": "קטע", "Line": "שורה", "Teshuva": "תשובה", "Teshuvah": "תשובה", "Volume": "כרך",
          "Mitzvah": "מצוה", "Negative Mitzvah": "מצות לא תעשה", "Positive Mitzvah": "מצות עשה", "Comment": "דיבור", "Gate": "שער",
          "Shaar": "שער", "Shorash": "שורש", "Shoresh": "שורש", "Remez": "רמז", "Klal": "כלל", "Sheilta": "שאילתא", "Parasha": "פרשה",
          "Drush": "דרוש", "Kovetz": "קובץ", "Midrash": "מדרש", "Discourse": "מאמר", "Chamber": "היכל", "Window": "חלון", "Torah": "תורה",
          "Part": "חלק", "Prayer": "תפילה", "Nahar": "נהר", "Psalm": "מזמור", "Letter": "אות", "Ot": "אות", "Teaching": "תורה",
          "Essay": "מאמר", "Story": "מעשה", "Page": "עמוד", "Question": "שאלה", "Treatise": "מסכת", "Book": "ספר", "Piska": "פסקא",
          "Introduction": "הקדמה", "Integer": "", "Talmud": "תלמוד"}
_ONES, _TENS, _HUND = " אבגדהוזחט", " יכלמנסעפצ", " קרשת"


def gim(n):
    """מספר -> אותיות (1 -> א, 15 -> טו, 121 -> קכא). מעל 999: המספר עצמו."""
    n = int(n)
    if not 0 < n < 1000:
        return str(n)
    s = "ת" * (n // 400) + _HUND[(n % 400) // 100].strip()
    r = n % 100
    s += "טו" if r == 15 else "טז" if r == 16 else (_TENS[r // 10] + _ONES[r % 10]).replace(" ", "")
    return s


def he_level(lv):
    m = re.fullmatch(r"(.*?)\s*(\d+)([ab]?)", lv.strip())
    if not m:
        return LEVELS.get(lv.strip(), lv.strip())
    name, num, side = m.groups()
    if name not in LEVELS:
        return lv.strip()
    out = (LEVELS[name] + " " + gim(num)).strip()
    return out + ({"a": " ע״א", "b": " ע״ב"}.get(side, ""))


def he_head(head):
    return " › ".join(he_level(lv) for lv in (head or "").split(" › ") if lv.strip()) if head else ""
