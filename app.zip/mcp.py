# -*- coding: utf-8 -*-
"""שרת MCP קטן (stdio) ש-Claude Code מפעיל: שני כלים, search ו-read, שפונים לאפליקציה שרצה במחשב (127.0.0.1:8418)."""
import json
import sys
import urllib.request

APP = "http://127.0.0.1:8418"
TOOLS = [
    {"name": "search", "description": "חיפוש בכל המאגרים המותקנים, לפי המשמעות ולפי המילים. מחזיר עד 8 קטעים: מזהה (passage), שם הספר (source), "
     "המקום בספר (head), המאגר (corpus), קטע קצר וקישור (url) לדף המקור. כדאי לשאול שאלה שלמה או לתאר רעיון.",
     "inputSchema": {"type": "object", "properties": {
         "query": {"type": "string", "description": "השאלה או הנושא, בעברית"},
         "corpus": {"type": "string", "description": "לא חובה: חיפוש במאגר אחד בלבד (yesod, otzar, shiurim, rimon, otzaria, hebrewbooks, asif, torani)"},
         "k": {"type": "integer", "description": "כמה תוצאות (ברירת מחדל 8, עד 20)"}}, "required": ["query"]}},
    {"name": "read", "description": "קריאת קטע מלא עם ההמשך שלו, לפי המזהה (passage) מתוצאות החיפוש.",
     "inputSchema": {"type": "object", "properties": {"passage": {"type": "string"}}, "required": ["passage"]}},
]


def call(path, body):
    req = urllib.request.Request(APP + path, data=json.dumps(body).encode("utf-8"), headers={"Content-Type": "application/json"}, method="POST")
    with urllib.request.urlopen(req, timeout=120) as r:
        return r.read().decode("utf-8")


def main():
    for line in sys.stdin.buffer:
        try:
            m = json.loads(line.decode("utf-8"))
        except ValueError:
            continue
        if "id" not in m:
            continue                       # הודעת notification: בלי תשובה
        method, p = m.get("method"), m.get("params") or {}
        try:
            if method == "initialize":
                res = {"protocolVersion": p.get("protocolVersion", "2024-11-05"), "capabilities": {"tools": {}},
                       "serverInfo": {"name": "sifriya", "version": "1.0"}}
            elif method == "tools/list":
                res = {"tools": TOOLS}
            elif method == "tools/call":
                a = p.get("arguments") or {}
                if p.get("name") == "search":
                    text = call("/api/search", {"query": a.get("query"), "corpus": a.get("corpus"), "k": a.get("k") or 8})
                else:
                    text = call("/api/read", {"passage": a.get("passage")})
                res = {"content": [{"type": "text", "text": text}]}
            elif method == "ping":
                res = {}
            else:
                out = {"jsonrpc": "2.0", "id": m["id"], "error": {"code": -32601, "message": "method not found"}}
                sys.stdout.buffer.write((json.dumps(out) + "\n").encode("utf-8"))
                sys.stdout.buffer.flush()
                continue
            out = {"jsonrpc": "2.0", "id": m["id"], "result": res}
        except Exception as e:  # noqa: BLE001
            out = {"jsonrpc": "2.0", "id": m["id"], "result": {"content": [{"type": "text", "text": "שגיאה: " + repr(e)[:200]}], "isError": True}}
        sys.stdout.buffer.write((json.dumps(out, ensure_ascii=False) + "\n").encode("utf-8"))
        sys.stdout.buffer.flush()


if __name__ == "__main__":
    main()
