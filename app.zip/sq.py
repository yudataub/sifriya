# -*- coding: utf-8 -*-
"""חיפוש בספרייה התורנית שמותקנת במחשב, משורת הפקודה (בשביל הסקיל של Claude). מפעיל את האפליקציה אם היא לא רצה.

    python sq.py -q "שאלה או נושא" [-c otzaria] [-k 8]     חיפוש לפי משמעות ולפי מילים
    python sq.py --read otzaria:123456                      קטע מלא עם ההמשך שלו
    python sq.py --list                                      המאגרים המותקנים
"""
import argparse
import json
import subprocess
import sys
import time
import urllib.request
from pathlib import Path

APP = "http://127.0.0.1:8418"
HERE = Path(__file__).parent


def up():
    try:
        return urllib.request.urlopen(APP + "/ping", timeout=3).read() == b"sifriya"
    except OSError:
        return False


def call(path, body=None):
    req = urllib.request.Request(APP + path, data=json.dumps(body).encode("utf-8") if body is not None else None,
                                 headers={"Content-Type": "application/json"})
    with urllib.request.urlopen(req, timeout=180) as r:
        return json.loads(r.read())


def main():
    sys.stdout.reconfigure(encoding="utf-8")
    p = argparse.ArgumentParser()
    p.add_argument("-q")
    p.add_argument("-c", "--corpus")
    p.add_argument("-k", type=int, default=8)
    p.add_argument("--read")
    p.add_argument("--list", action="store_true")
    a = p.parse_args()
    if not up():
        subprocess.Popen([sys.executable, str(HERE / "app.py"), "--quiet"], cwd=HERE, creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
                         stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        for _ in range(40):
            time.sleep(1)
            if up():
                break
        else:
            return print("האפליקציה לא עלתה. הפעילו אותה מקיצור הדרך Sifriya שעל שולחן העבודה.")
    if a.list:
        for c in call("/api/state")["installed"]:
            print(f"{c['slug']}: {c['name']} ({c['books']} ספרים)")
        return
    if a.read:
        r = call("/api/read", {"passage": a.read})
        if r.get("error"):
            return print(r["error"])
        print(r["source"] + (" › " + r["head"] if r.get("head") else ""))
        print(r["url"])
        print(r["text"])
        if r.get("next"):
            print("\n[ההמשך: --read " + r["next"] + "]")
        return
    if not a.q:
        return p.print_help()
    r = call("/api/search", {"query": a.q, "corpus": a.corpus, "k": a.k, "long": True})
    if r.get("error"):
        return print(r["error"])
    if not r["results"]:
        return print("לא נמצא דבר. נסו ניסוח אחר.")
    for x in r["results"]:
        print(f"[{x['passage']}] {x['source']}" + (" › " + x["head"] if x.get("head") else "") + f"  ({x['corpus']}, {x['by']})")
        print(x["url"])
        print(x["excerpt"])
        print()


if __name__ == "__main__":
    main()
