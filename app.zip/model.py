"""bge-m3 במחשב (ONNX, בלי אינטרנט). אותו מודל שבו הוטמעו הקטעים, ולכן וקטור השאלה תואם לווקטורים שבמאגרים."""
import os
from pathlib import Path

import numpy as np

DIR = Path(__file__).parent / "data" / "model"
_sess = _tok = None


def load(threads=None):
    global _sess, _tok
    if _sess is None:
        import onnxruntime as ort
        from tokenizers import Tokenizer
        so = ort.SessionOptions()
        so.intra_op_num_threads = threads or min(8, os.cpu_count() or 4)
        so.graph_optimization_level = ort.GraphOptimizationLevel.ORT_ENABLE_ALL
        _sess = ort.InferenceSession(str(DIR / "onnx" / "model.onnx"), so, providers=["CPUExecutionProvider"])
        _tok = Tokenizer.from_file(str(DIR / "tokenizer.json"))
        _tok.enable_truncation(8192)
    return _sess, _tok


def embed(texts, threads=None):
    """רשימת טקסטים -> מטריצה float32 מנורמלת (n x 1024)."""
    sess, tok = load(threads)
    enc = tok.encode_batch(list(texts))
    n = max(len(e.ids) for e in enc)
    ids = np.full((len(enc), n), tok.token_to_id("<pad>") or 1, dtype=np.int64)
    mask = np.zeros((len(enc), n), dtype=np.int64)
    for i, e in enumerate(enc):
        ids[i, :len(e.ids)] = e.ids
        mask[i, :len(e.ids)] = 1
    names = {i.name for i in sess.get_inputs()}
    feed = {"input_ids": ids, "attention_mask": mask}
    if "token_type_ids" in names:
        feed["token_type_ids"] = np.zeros_like(ids)
    outs = sess.run(None, {k: v for k, v in feed.items() if k in names})
    onames = [o.name for o in sess.get_outputs()]
    out = outs[onames.index("dense_vecs")] if "dense_vecs" in onames else outs[0]
    if out.ndim == 3:            # last_hidden_state -> CLS
        out = out[:, 0]
    out = out.astype(np.float32)
    return out / np.linalg.norm(out, axis=1, keepdims=True)
