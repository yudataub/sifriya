# -*- coding: utf-8 -*-
"""הספרייה התורנית במחשב: התקנת מאגרים, חיפוש לפי משמעות ולפי מילים, דף מקורות, ושאלות ל-Claude של המשתמש.

    python app.py            מפעיל את השרת (127.0.0.1:8418) ופותח את הדפדפן
    python app.py --quiet    בלי לפתוח דפדפן

הכול נשאר במחשב. האינטרנט נדרש רק להורדת המאגרים והמודל, ול-Claude עצמו (דרך Claude Code שמותקן ומחובר במחשב).
המבנה:  data/<מאגר>/search.db, vec.f16, vec.ids   ·   data/model/ (bge-m3)   ·   dl/ (הורדות זמניות)
"""
import base64
import gzip
import hashlib
import json
import os
import re
import shutil
import sqlite3
import struct
import subprocess
import sys
import threading
import time
import urllib.request
import webbrowser
import zlib
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlparse, parse_qs, quote

HERE = Path(__file__).parent
sys.path.insert(0, str(HERE))
from he import fts_query, excerpt, norm  # noqa: E402

PORT = 8418
DATA, DL = HERE / "data", HERE / "dl"
SITE = os.environ.get("SIFRIYA_SITE", "https://yudataub.github.io/sifriya/")        # משתני הסביבה: רק לבדיקה מקומית
REL = os.environ.get("SIFRIYA_REL", "")
SFARIM = "https://sfarim.kol-toda.co.il/" + quote("ספרי יהודה טאוב/שיעורי יוטיוב") + "/"
MODEL_FILES = [("tokenizer.json", 1), ("onnx/model.onnx", 1), ("onnx/model.onnx_data", 2)]     # (קובץ, מספר החלקים בגרסה model)
RRF_K, LEX_N, SEM_N, PRIM_N, W_PRIM = 60, 60, 80, 12, 0.7
PRIMARY_RE = re.compile("|".join([           # מקורות היסוד עצמם (בלי המפרשים): מקבלים מסלול משלהם, כדי שהמפרשים לא ידחקו אותם
    r"^תנך/(Torah|Prophets|Writings)/", r"^משנה/סדר_", r"^תלמוד/בבלי/סדר_", r"^תלמוד/ירושלמי/סדר_",
    r"^תוספתא/(?!.*(Commentary|פירוש))", r"^מדרש/הלכה/(?!Commentary)", r"^מדרש/אגדה/Midrash Rabbah/(?!Commentary)",
    r"^מדרש/אגדה/(Midrash Tanchuma|Midrash Tanchuma Buber|Pirkei DeRabbi Eliezer|Midrash Tehillim|Pesikta D'Rav Kahanna|Pesikta Rabbati)/",
    r"^הלכה/הלכה א/משנה_תורה/Sefer ", r"^הלכה/הלכה א/שולחן_ערוך/Shulchan Arukh, "]))

KEY = None                 # מפתח הפענוח: רק בזיכרון, רק בזמן ההתקנה
MAN = None                 # רשימת המאגרים שאפשר להוריד (אחרי הקשת הקוד)
JOB = {"on": False, "msg": "", "done": 0, "total": 0, "err": "", "log": []}
CORP = {}                  # slug -> Corp
LOCK = threading.Lock()


# ---------------------------------------------------------------- מאגרים מותקנים
class Corp:
    def __init__(self, slug):
        import numpy as np
        d = DATA / slug
        self.slug, self.dir = slug, d
        self.meta = json.loads((d / "meta.json").read_text(encoding="utf-8"))
        self.name = self.meta["name"]
        self.ids = np.fromfile(d / "vec.ids", dtype=np.int32)
        self.vec = np.memmap(d / "vec.f16", dtype=np.float16, mode="r").reshape(-1, 1024) if len(self.ids) else None
        self.prim = None
        if slug == "yesod":
            db = self.db()
            docs = [r[0] for r in db.execute("SELECT id, file FROM docs") if PRIMARY_RE.search(r[1])]
            got = [r[0] for r in db.execute("SELECT id FROM chunks WHERE live=1 AND doc IN (%s)" % ",".join(map(str, docs)))] if docs else []
            db.close()
            self.prim = np.isin(self.ids, np.asarray(got, dtype=np.int32))

    def db(self):
        return sqlite3.connect(f"file:{(self.dir / 'search.db').as_posix()}?mode=ro", uri=True)


def load_corpora():
    CORP.clear()
    if DATA.exists():
        for d in sorted(DATA.iterdir()):
            if (d / "meta.json").exists() and (d / "search.db").exists():
                try:
                    CORP[d.name] = Corp(d.name)
                except Exception as e:  # noqa: BLE001
                    print("מאגר לא נטען", d.name, repr(e)[:200], flush=True)


def model_ready():
    return all((DATA / "model" / f).exists() for f, _ in MODEL_FILES)


# ---------------------------------------------------------------- חיפוש
def lexical(c, q, n=LEX_N):
    expr, words = fts_query(q)
    if not expr:
        return [], []
    db = c.db()
    try:
        run = lambda e: [r[0] for r in db.execute("SELECT rowid FROM fts WHERE fts MATCH ? ORDER BY bm25(fts, 4.0, 1.0) LIMIT ?", (e, n))]
        ids = run(expr)
        if len(ids) < 10 and len(words) > 1:
            have = set(ids)
            ids += [i for i in run(fts_query(q, True)[0]) if i not in have]
    finally:
        db.close()
    return ids[:n], words


def semantic(v, corps):
    """הקרובים במשמעות בכל המאגרים יחד, ובנפרד במקורות היסוד. [(slug, id)], [(slug, id)]"""
    import numpy as np
    allc, prim = [], []
    for c in corps:
        if c.vec is None:
            continue
        s = np.concatenate([np.asarray(c.vec[i:i + 100000]).astype(np.float32) @ v for i in range(0, len(c.vec), 100000)])
        n = min(SEM_N, len(s))
        idx = np.argpartition(-s, n - 1)[:n]
        allc += [(float(s[i]), c.slug, int(c.ids[i])) for i in idx]
        if c.prim is not None and c.prim.any():
            sp = np.where(c.prim, s, -9.0)
            idx = np.argpartition(-sp, PRIM_N - 1)[:PRIM_N]
            prim += [(float(sp[i]), c.slug, int(c.ids[i])) for i in idx if sp[i] > -8]
    allc.sort(reverse=True)
    prim.sort(reverse=True)
    return [(s, i) for _, s, i in allc[:SEM_N]], [(s, i) for _, s, i in prim]


def search(q, k=8, corp=None, long=False):
    q = (q or "").strip()[:300]
    if not q:
        return {"error": "שאלה ריקה"}
    corps = [CORP[corp]] if corp in CORP else list(CORP.values())
    if not corps:
        return {"error": "עוד לא הותקן אף מאגר"}
    score, by, words = {}, {}, []

    def add(lst, kind, w):
        for i, key in enumerate(lst):
            score[key] = score.get(key, 0) + w / (RRF_K + i)
            by[key] = by.get(key, 0) | kind
    for c in corps:
        ids, words = lexical(c, q)
        add([(c.slug, i) for i in ids], 1, 1.0)
    sem_ok = True
    try:
        from model import embed
        with LOCK:
            v = embed([q])[0]
        sem, prim = semantic(v, corps)
        add(sem, 2, 1.0)
        add(prim, 2, W_PRIM)
    except Exception as e:  # noqa: BLE001
        print("semantic", repr(e)[:200], flush=True)
        sem_ok = False
    ranked = sorted(score, key=score.get, reverse=True)[:k * 6]
    out, per, size = [], {}, 900 if long else 500
    dbs = {c.slug: c.db() for c in corps}
    try:
        for slug, cid in ranked:
            r = dbs[slug].execute("SELECT c.doc, c.head, c.text, d.title FROM chunks c JOIN docs d ON d.id=c.doc WHERE c.id=?", (cid,)).fetchone()
            if not r:
                continue
            per[(slug, r[0])] = per.get((slug, r[0]), 0) + 1
            if per[(slug, r[0])] > 2:
                continue
            out.append({"passage": f"{slug}:{cid}", "source": r[3], **({"head": r[1]} if r[1] else {}), "corpus": CORP[slug].name.split(" – ")[0],
                        "url": f"http://127.0.0.1:{PORT}/r/{slug}/p{cid}" + ("?q=" + quote(" ".join(words)) if words else ""),
                        "by": {1: "מילים", 2: "משמעות", 3: "מילים ומשמעות"}[by[(slug, cid)]], "excerpt": excerpt(r[2], words, size)})
            if len(out) >= k:
                break
    finally:
        for d in dbs.values():
            d.close()
    return {"query": q, "results": out, "semantic": sem_ok}


def read(passage):
    try:
        slug, cid = passage.split(":")
        cid = int(cid)
        db = CORP[slug].db()
    except Exception:  # noqa: BLE001
        return {"error": "אין קטע כזה"}
    try:
        rows = db.execute("SELECT c.id, c.doc, c.head, c.text, d.title FROM chunks c JOIN docs d ON d.id=c.doc WHERE c.id IN (?,?) ORDER BY c.id",
                          (cid, cid + 1)).fetchall()
    finally:
        db.close()
    if not rows or rows[0][0] != cid:
        return {"error": "אין קטע כזה"}
    nxt = rows[1] if len(rows) > 1 and rows[1][1] == rows[0][1] else None
    return {"source": rows[0][4], **({"head": rows[0][2]} if rows[0][2] else {}), "url": f"http://127.0.0.1:{PORT}/r/{slug}/p{cid}",
            "text": rows[0][3] + ("\n\n" + nxt[3] if nxt else ""), **({"next": f"{slug}:{cid + 1}"} if nxt else {})}


# ---------------------------------------------------------------- דף המקורות
def r_info(c, cid):
    db = c.db()
    try:
        r = db.execute("SELECT d.id, d.title, d.file, d.cat FROM chunks c JOIN docs d ON d.id=c.doc WHERE c.id=?", (cid,)).fetchone()
        if not r:
            return None
        lo, hi = db.execute("SELECT MIN(id), MAX(id) FROM chunks WHERE doc=?", (r[0],)).fetchone()
    finally:
        db.close()
    url, f = "", r[2]
    if f.startswith("asif:"):
        m = re.match(r"(\d+)_", f.rsplit("/", 1)[-1])
        url = f"https://asif.co.il/?p={m[1]}" if m else ""
    elif f.startswith("shiurim:"):
        url = SFARIM + quote(f[len("shiurim:"):])
    return {"doc": r[0], "title": r[1], "cat": r[3], "lo": lo, "hi": hi, "target": cid, "corpus": c.name.split(" – ")[0], "path": "", "url": url}


def r_chunks(c, a, b):
    db = c.db()
    try:
        d = db.execute("SELECT doc FROM chunks WHERE id=?", (a,)).fetchone()
        rows = db.execute("SELECT id, head, text, fmt FROM chunks WHERE doc=? AND id BETWEEN ? AND ? ORDER BY id", (d[0], a, min(b, a + 79))).fetchall() if d else []
    finally:
        db.close()
    out = []
    for cid, head, text, fmt in rows:
        it = {"id": cid, "head": head or "", "text": text}
        if fmt:
            f = json.loads(fmt)
            ps = [p for p in text.split("\n") if p]
            if len(ps) == len(f) - 1:
                it["pars"], it["end"] = [[p, f[i][0], f[i][1], f[i][2]] for i, p in enumerate(ps)], f[-1]
        out.append(it)
    return out


def r_toc(c, doc):
    db = c.db()
    try:
        return [[r[0], r[1]] for r in db.execute("SELECT MIN(id), head FROM chunks WHERE doc=? AND head IS NOT NULL AND head<>'' "
                                                 "GROUP BY head ORDER BY MIN(id) LIMIT 6000", (doc,))]
    finally:
        db.close()


def books(c):
    db = c.db()
    try:
        return [[r[0], r[1], r[2].replace("_", " ")] for r in db.execute(
            "SELECT (SELECT MIN(id) FROM chunks WHERE doc=d.id), d.title, d.cat FROM docs d WHERE d.n>0 ORDER BY d.id")]
    finally:
        db.close()


# ---------------------------------------------------------------- התקנה: הורדה, פענוח ובנייה
def say(msg):
    JOB["msg"] = msg
    JOB["log"] = (JOB["log"] + [msg])[-30:]


def fetch(url, dest, size=None):
    """הורדה עם המשך מאיפה שנעצר. מעדכן את JOB["done"]."""
    dest.parent.mkdir(parents=True, exist_ok=True)
    have = dest.stat().st_size if dest.exists() else 0
    if size and have == size:
        JOB["done"] += have
        return
    if size and have > size:
        dest.unlink()
        have = 0
    JOB["done"] += have
    for attempt in range(8):
        try:
            req = urllib.request.Request(url, headers={"User-Agent": "sifriya-app", **({"Range": f"bytes={have}-"} if have else {})})
            with urllib.request.urlopen(req, timeout=60) as r, open(dest, "ab" if have and r.status == 206 else "wb") as f:
                if have and r.status != 206:
                    JOB["done"] -= have
                    have = 0
                while True:
                    b = r.read(1 << 20)
                    if not b:
                        break
                    f.write(b)
                    have += len(b)
                    JOB["done"] += len(b)
            if not size or have == size:
                return
        except Exception as e:  # noqa: BLE001
            say(f"ההורדה נקטעה, מנסה שוב ({attempt + 1})… {repr(e)[:80]}")
            time.sleep(5)
    raise RuntimeError("ההורדה נכשלה: " + url.rsplit("/", 1)[-1])


def records(paths, key):
    """קורא את הרשומות המוצפנות ([אורך][IV][טקסט מוצפן]) מרצף קבצים, ומחזיר את התוכן המפוענח."""
    from cryptography.hazmat.primitives.ciphers.aead import AESGCM
    aes, buf = AESGCM(key), b""
    files = iter(paths)
    f = open(next(files), "rb")

    def need(n):
        nonlocal buf, f
        while len(buf) < n:
            b = f.read(max(n - len(buf), 1 << 20))
            if not b:
                f.close()
                nxt = next(files, None)
                if nxt is None:
                    return False
                f = open(nxt, "rb")
                continue
            buf += b
        return True
    while need(4):
        n = struct.unpack(">I", buf[:4])[0]
        if not need(4 + 12 + n):
            raise RuntimeError("קובץ קטוע")
        yield aes.decrypt(buf[4:16], buf[16:16 + n], None)
        buf = buf[16 + n:]
    f.close()


def unpack(base, info, dest, key, gz=False):
    """מוריד את חלקי הקובץ, מפענח (ופותח דחיסה) ל-dest, בודק, ומוחק את החלקים."""
    parts = []
    for name, size in info["parts"]:
        fetch(base + name, DL / name, size)
        parts.append(DL / name)
    sha, n = hashlib.sha256(), 0
    z = zlib.decompressobj(31) if gz else None
    with open(dest, "wb") as out:
        for raw in records(parts, key):
            sha.update(raw)
            n += len(raw)
            out.write(z.decompress(raw) if z else raw)
        if z:
            out.write(z.flush())
    if n != info["size"] or sha.hexdigest() != info["sha"]:
        raise RuntimeError("הקובץ שירד פגום: " + dest.name)
    for p in parts:
        p.unlink()


def build_fts(path, name):
    db = sqlite3.connect(path)
    db.executescript("PRAGMA journal_mode=OFF; PRAGMA synchronous=OFF; DROP TABLE IF EXISTS fts;"
                     "CREATE VIRTUAL TABLE fts USING fts5(title, body, content='', columnsize=0, tokenize='unicode61');")
    total = db.execute("SELECT COUNT(*) FROM chunks WHERE live=1").fetchone()[0]
    cur = db.execute("SELECT c.id, d.title, c.head, c.text FROM chunks c JOIN docs d ON d.id=c.doc WHERE c.live=1")
    w, n = db.cursor(), 0
    while True:
        rows = cur.fetchmany(20000)
        if not rows:
            break
        w.executemany("INSERT INTO fts(rowid,title,body) VALUES(?,?,?)", [(r[0], norm(r[1] + " " + (r[2] or "")), norm(r[3])) for r in rows])
        n += len(rows)
        say(f"{name}: בונה את חיפוש המילים ({n * 100 // max(total, 1)}%)")
    db.execute("INSERT INTO fts(fts) VALUES('optimize')")
    db.commit()
    db.close()


def install(slugs):
    try:
        base = REL or f"https://github.com/{MAN['repo']}/releases/download/"
        todo = [c for c in MAN["corpora"] if c["slug"] in slugs]
        JOB.update(on=True, err="", done=0, log=[], total=sum(c["download"] for c in todo) + (0 if model_ready() else 2_290_000_000))
        free = shutil.disk_usage(HERE).free
        needed = sum(c["disk"] + c["download"] for c in todo) + (0 if model_ready() else 2_400_000_000)
        if free < needed:
            raise RuntimeError(f"אין מספיק מקום בדיסק: צריך כ-{needed / 1e9:.0f}GB, פנויים {free / 1e9:.0f}GB")
        for c in todo:
            d = DATA / (c["slug"] + ".new")
            shutil.rmtree(d, ignore_errors=True)
            d.mkdir(parents=True)
            say(f"{c['name'].split(' – ')[0]}: מוריד את הטקסט")
            key = base64.b64decode(c["key"])
            unpack(base + MAN["tag"] + "/", c["files"]["db"], d / "search.db", key, gz=True)
            say(f"{c['name'].split(' – ')[0]}: מוריד את נתוני המשמעות")
            unpack(base + MAN["tag"] + "/", c["files"]["vec"], d / "vec.f16", key)
            unpack(base + MAN["tag"] + "/", c["files"]["ids"], d / "vec.ids", key)
            build_fts(d / "search.db", c["name"].split(" – ")[0])
            (d / "meta.json").write_text(json.dumps({k: c[k] for k in ("slug", "name", "books", "chunks", "vectors")}, ensure_ascii=False), encoding="utf-8")
            old = DATA / c["slug"]
            CORP.pop(c["slug"], None)
            shutil.rmtree(old, ignore_errors=True)
            d.rename(old)
            CORP[c["slug"]] = Corp(c["slug"])
        if not model_ready():
            say("מוריד את מודל החיפוש לפי משמעות (פעם אחת, 2.2GB)")
            for f, n in MODEL_FILES:
                dest = DATA / "model" / f
                dest.parent.mkdir(parents=True, exist_ok=True)
                name = f.rsplit("/", 1)[-1]
                if n == 1:
                    fetch(base + "model/" + name, dest.with_suffix(dest.suffix + ".part"))
                    dest.with_suffix(dest.suffix + ".part").replace(dest)
                else:
                    ps = []
                    for i in range(1, n + 1):
                        fetch(base + f"model/{name}.{i:03d}", DL / f"{name}.{i:03d}")
                        ps.append(DL / f"{name}.{i:03d}")
                    with open(str(dest) + ".part", "wb") as out:
                        for p in ps:
                            with open(p, "rb") as src:
                                shutil.copyfileobj(src, out, 8 << 20)
                    Path(str(dest) + ".part").replace(dest)
                    for p in ps:
                        p.unlink()
        say("ההתקנה הסתיימה")
    except Exception as e:  # noqa: BLE001
        JOB["err"] = str(e)[:300]
        say("שגיאה: " + JOB["err"])
    finally:
        JOB["on"] = False


def unlock(code):
    """הקוד -> מפתח -> רשימת המאגרים. הקוד עצמו לא נשמר."""
    global KEY, MAN
    from cryptography.hazmat.primitives.ciphers.aead import AESGCM
    with urllib.request.urlopen(urllib.request.Request(SITE + "pkg.json", headers={"User-Agent": "sifriya-app"}), timeout=30) as r:
        m = json.loads(r.read())
    for e in m["m"]:                    # רשומה לכל קוד: קוד הספרייה פותח את כל המאגרים, קוד התקנה פותח רק את שלו
        key = hashlib.pbkdf2_hmac("sha256", code.strip().encode("utf-8"), base64.b64decode(e["s"]), e["r"], 32)
        chk = base64.b64decode(e["chk"])
        try:
            AESGCM(key).decrypt(chk[:12], chk[12:], None)
        except Exception:  # noqa: BLE001
            continue
        raw = base64.b64decode(e["enc"])
        KEY, MAN = key, json.loads(gzip.decompress(AESGCM(key).decrypt(raw[:12], raw[12:], None)))
        return True
    return False


# ---------------------------------------------------------------- Claude של המשתמש (Claude Code שמותקן ומחובר במחשב)
def claude_path():
    p = shutil.which("claude")
    if p:
        return p
    for c in (Path.home() / ".local" / "bin" / "claude.exe", Path(os.environ.get("APPDATA", "")) / "npm" / "claude.cmd"):
        if c.exists():
            return str(c)
    return None


def ask(q, session, send):
    exe = claude_path()
    if not exe:
        return send({"t": "need", "v": "install"})
    (HERE / "chat").mkdir(exist_ok=True)
    cfg = HERE / "chat" / "mcp.json"
    cfg.write_text(json.dumps({"mcpServers": {"sifriya": {"command": sys.executable.replace("pythonw.exe", "python.exe"), "args": [str(HERE / "mcp.py")]}}}), encoding="utf-8")
    cmd = [exe, "-p", "--output-format", "stream-json", "--verbose", "--include-partial-messages",
           "--append-system-prompt-file", str(HERE / "prompt.md"), "--mcp-config", str(cfg), "--strict-mcp-config",
           "--allowedTools", "mcp__sifriya__search,mcp__sifriya__read",
           "--disallowedTools", "Bash,PowerShell,Edit,Write,Read,Glob,Grep,WebFetch,WebSearch,Agent,Task,NotebookEdit,Skill"]
    if session:
        cmd += ["--resume", session]
    flags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
    p = subprocess.Popen(cmd, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE, cwd=HERE / "chat", creationflags=flags)
    p.stdin.write(q.encode("utf-8"))
    p.stdin.close()
    sid, got = session, False
    try:
        for line in p.stdout:
            try:
                e = json.loads(line.decode("utf-8", "replace"))
            except ValueError:
                continue
            t = e.get("type")
            if e.get("session_id"):
                sid = e["session_id"]
            if t == "stream_event":
                ev = e.get("event", {})
                if ev.get("type") == "content_block_delta" and ev.get("delta", {}).get("type") == "text_delta":
                    got = True
                    send({"t": "text", "v": ev["delta"]["text"]})
                elif ev.get("type") == "content_block_start" and ev.get("content_block", {}).get("type") == "text" and got:
                    send({"t": "text", "v": "\n\n"})
            elif t == "assistant":
                for b in e.get("message", {}).get("content", []):
                    if b.get("type") == "tool_use" and str(b.get("name", "")).startswith("mcp__sifriya__"):
                        i = b.get("input", {})
                        send({"t": "tool", "v": i.get("query") or ("קורא " + str(i.get("passage", "")))})
            elif t == "result":
                if e.get("is_error") or e.get("subtype") != "success":
                    msg = str(e.get("result") or e.get("subtype") or "")
                    send({"t": "need", "v": "login"} if re.search(r"/login|API key|authenticat|not logged", msg, re.I) else {"t": "err", "v": msg[:300]})
                elif not got and e.get("result"):
                    send({"t": "text", "v": e["result"]})
    finally:
        p.wait()
        err = p.stderr.read().decode("utf-8", "replace")[-300:]
        if p.returncode and not got:
            send({"t": "need", "v": "login"} if re.search(r"/login|API key|authenticat|not logged", err, re.I) else {"t": "err", "v": err or "Claude לא ענה"})
        send({"t": "done", "session": sid})


# ---------------------------------------------------------------- השרת
def reader_page(info, slug):
    page = (HERE / "reader.html").read_text(encoding="utf-8")
    return page.replace("/*INFO*/null", json.dumps(info, ensure_ascii=False).replace("</", "<\\/"))


class H(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"

    def send(self, body, ctype="application/json; charset=utf-8", code=200):
        if not isinstance(body, (bytes, str)):
            body = json.dumps(body, ensure_ascii=False)
        body = body.encode("utf-8") if isinstance(body, str) else body
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def body(self):
        n = int(self.headers.get("Content-Length") or 0)
        return json.loads(self.rfile.read(n)) if 0 < n < 200000 else {}

    def do_GET(self):
        u = urlparse(self.path)
        q = parse_qs(u.query)
        try:
            if u.path == "/":
                return self.send((HERE / "ui.html").read_text(encoding="utf-8"), "text/html; charset=utf-8")
            if u.path == "/frl.woff2":
                return self.send((HERE / "frl.woff2").read_bytes(), "font/woff2")
            if u.path == "/api/state":
                exe = claude_path()
                return self.send({"installed": [dict(c.meta) for c in CORP.values()], "model": model_ready(), "claude": bool(exe),
                                  "unlocked": MAN is not None, "job": JOB, "preset": preset(),
                                  "corpora": [{k: c[k] for k in ("slug", "name", "books", "chunks", "download", "disk")} for c in MAN["corpora"]] if MAN else []})
            if u.path == "/api/books":
                c = CORP.get(q.get("c", [""])[0])
                return self.send(books(c) if c else [])
            m = re.fullmatch(r"/r/([a-z]+)/(p(\d+)|api/chunks|api/toc)", u.path)
            if m and m[1] in CORP:
                c = CORP[m[1]]
                if m[3]:
                    i = r_info(c, int(m[3]))
                    return self.send(reader_page(i, m[1]), "text/html; charset=utf-8") if i else self.send("אין קטע כזה", "text/plain; charset=utf-8", 404)
                if m[2] == "api/chunks":
                    return self.send(r_chunks(c, int(q["a"][0]), int(q["b"][0])))
                return self.send(r_toc(c, int(q["doc"][0])))
            if u.path == "/ping":
                return self.send("sifriya", "text/plain")
        except Exception as e:  # noqa: BLE001
            return self.send({"error": repr(e)[:300]}, code=500)
        self.send("לא נמצא", "text/plain; charset=utf-8", 404)

    def do_POST(self):
        if self.client_address[0] != "127.0.0.1":
            return self.send({"error": "forbidden"}, code=403)
        try:
            b = self.body()
            if self.path == "/api/search":
                return self.send(search(b.get("query"), min(20, int(b.get("k") or 8)), b.get("corpus"), bool(b.get("long"))))
            if self.path == "/api/read":
                return self.send(read(str(b.get("passage") or "")))
            if self.path == "/api/unlock":
                return self.send({"ok": unlock(str(b.get("code") or ""))})
            if self.path == "/api/install":
                if JOB["on"]:
                    return self.send({"error": "התקנה כבר רצה"})
                if not MAN:
                    return self.send({"error": "קודם מקישים את הקוד"})
                JOB["on"] = True
                (HERE / "preset.txt").unlink(missing_ok=True)
                threading.Thread(target=install, args=([str(s) for s in b.get("slugs", [])],), daemon=True).start()
                return self.send({"ok": True})
            if self.path == "/api/remove":
                s = str(b.get("slug") or "")
                if re.fullmatch(r"[a-z]+", s) and s in CORP and not JOB["on"]:
                    CORP.pop(s)
                    shutil.rmtree(DATA / s, ignore_errors=True)
                return self.send({"ok": True})
            if self.path == "/api/claude":
                what = b.get("do")
                if what == "install":          # ההתקנה הרשמית של Claude Code, בחלון משלה, כדי שהמשתמש יראה מה קורה
                    subprocess.Popen('start "Claude" powershell -NoExit -Command "irm https://claude.ai/install.ps1 | iex"', shell=True)
                elif what == "login" and claude_path():
                    subprocess.Popen(f'start "Claude" cmd /k ""{claude_path()}""', shell=True)
                return self.send({"ok": True})
            if self.path == "/api/ask":
                self.send_response(200)
                self.send_header("Content-Type", "text/event-stream; charset=utf-8")
                self.send_header("Cache-Control", "no-cache")
                self.send_header("Connection", "close")
                self.end_headers()

                def send(o):
                    try:
                        self.wfile.write(("data: " + json.dumps(o, ensure_ascii=False) + "\n\n").encode("utf-8"))
                        self.wfile.flush()
                    except OSError:
                        pass
                try:
                    ask(str(b.get("q") or "")[:4000], b.get("session") or None, send)
                except Exception as e:  # noqa: BLE001
                    send({"t": "err", "v": repr(e)[:300]})
                    send({"t": "done", "session": b.get("session")})
                self.close_connection = True
                return
        except Exception as e:  # noqa: BLE001
            return self.send({"error": repr(e)[:300]}, code=500)
        self.send({"error": "not_found"}, code=404)

    def log_message(self, *x):
        pass


def preset():
    """מאגרים שקובץ ההתקנה ביקש להתקין מיד אחרי הקשת הקוד (preset.txt, נמחק כשההתקנה מתחילה)."""
    try:
        return [s for s in (HERE / "preset.txt").read_text(encoding="utf-8").strip().split(",") if re.fullmatch(r"[a-z]+", s)]
    except OSError:
        return []


def install_skill():
    """סקיל ל-Claude Code של המשתמש: כשמבקשים "תחפש באוצריא" / "בספרייה התורנית", Claude מחפש במאגרים המותקנים (sq.py)."""
    d = Path.home() / ".claude" / "skills" / "sifriya-search"
    d.mkdir(parents=True, exist_ok=True)
    text = (HERE / "SKILL.md").read_text(encoding="utf-8").replace("{SQ}", (HERE / "sq.py").as_posix())
    (d / "SKILL.md").write_text(text, encoding="utf-8")
    print("skill installed:", d)


def main():
    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except Exception:  # noqa: BLE001
        pass
    if "--skill" in sys.argv:
        return install_skill()
    url = f"http://127.0.0.1:{PORT}/"
    try:
        srv = ThreadingHTTPServer(("127.0.0.1", PORT), H)
    except OSError:                 # כבר רץ: רק פותחים את הדפדפן
        if "--quiet" not in sys.argv:
            webbrowser.open(url)
        return
    load_corpora()
    if "--quiet" not in sys.argv:
        threading.Timer(0.8, lambda: webbrowser.open(url)).start()
    srv.serve_forever()


if __name__ == "__main__":
    main()
